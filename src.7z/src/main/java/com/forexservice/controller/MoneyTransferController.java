
package com.forexservice.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.forexservice.entity.MoneyTransfer;
import com.forexservice.exception.MoneyTransferNotFoundException;
import com.forexservice.service.MoneyTransferService;

@RestController


public class MoneyTransferController {

	@Autowired
		private MoneyTransferService moneytransferservice;
	
	@PostMapping("moneytransfer")
	public MoneyTransfer addMoneyTransfer(@Valid @RequestBody MoneyTransfer  moneytransfer) throws MoneyTransferNotFoundException {
		return this.moneytransferservice.addMoneyTransfer(moneytransfer);

}
	
	
	@PutMapping("moneytransfer")
  	public MoneyTransfer updateMoneyTransfer(@RequestBody MoneyTransfer moneytransfer) throws MoneyTransferNotFoundException {
  		return this.moneytransferservice.updateMoneyTransfer(moneytransfer);
  	}
	
	
	
	
	  @DeleteMapping("moneytransfer/{moneytransferId}")
      public boolean deleteMoneyTransferById(@PathVariable("transferId")Integer moneytransferId) {
	return this.moneytransferservice.deleteMoneyTransferById(moneytransferId);
}
	  
	  
	  
	  @GetMapping("moneytransfer/{id}")
		public MoneyTransfer getMoneyTransferById(@PathVariable("id") Integer maneytransferId ){
			return this.moneytransferservice. getMoneyTransferById(maneytransferId);
		}
	
	@GetMapping("moneytransfers")
	public List<MoneyTransfer>getAllMoneyTransferDetails (){
		return this.moneytransferservice.getAllMoneyTransferDetails();
	}

}

	





