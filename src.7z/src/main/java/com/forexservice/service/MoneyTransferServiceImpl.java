package com.forexservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.forexservice.entity.MoneyTransfer;
import com.forexservice.entity.Transfer;
import com.forexservice.exception.MoneyTransferNotFoundException;
import com.forexservice.repository.MoneyTransferRepository;

@Service
public class MoneyTransferServiceImpl implements MoneyTransferService {
	
	@Autowired
    private MoneyTransferRepository moneytransferRepo;



   @Override
    public MoneyTransfer addMoneyTransfer ( MoneyTransfer  moneytransfer) throws MoneyTransferNotFoundException {
        
        return this.moneytransferRepo.save(moneytransfer);
    }
   
   @Override
   public MoneyTransfer updateMoneyTransfer(MoneyTransfer moneytransfer) throws MoneyTransferNotFoundException {
	   Optional<MoneyTransfer> moneytransferOpt = this.moneytransferRepo.findById(moneytransfer.getUseraccountId());
       if (moneytransferOpt.isEmpty())
           throw new MoneyTransferNotFoundException("MoneyTransfer id does not exist to update.");



      MoneyTransfer updateMoneyTransfer = moneytransfer.get();
       //updateMoneyTransfer.setUseraccountId(moneytransfer.getUseraccountId());
       return this.moneytransferRepo.save(updateMoneyTransfer);
			   
			   		   
}

@Override
public boolean deleteMoneyTransferById(Integer moneytransferId) {
	// TODO Auto-generated method stub
	return false;
}

@Override
public MoneyTransfer getMoneyTransferById(Integer maneytransferId) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public List<MoneyTransfer> getAllMoneyTransferDetails() {
	// TODO Auto-generated method stub
	return null;
}
}
