package com.forexservice.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.forexservice.entity.MoneyTransfer;
import com.forexservice.exception.MoneyTransferNotFoundException;

public interface MoneyTransferService {
	
	public MoneyTransfer addMoneyTransfer ( MoneyTransfer  moneytransfer) throws MoneyTransferNotFoundException;
	public MoneyTransfer updateMoneyTransfer( MoneyTransfer moneytransfer) throws MoneyTransferNotFoundException;
	public boolean deleteMoneyTransferById(Integer moneytransferId);
	public MoneyTransfer getMoneyTransferById(Integer maneytransferId);
	public List<MoneyTransfer> getAllMoneyTransferDetails();
}

