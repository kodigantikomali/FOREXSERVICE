package com.forexservice.entity;
import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MoneyTransfer") 

public class MoneyTransfer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private Integer useraccountId;
	private String fromcountry;
	private String tocountry;
	private double currencyexchangerate;
	private Double amount;
	private Double totalamount;
	private String comments;
	private LocalDate date;
	
	
	public MoneyTransfer() {
		super();
	}
	public MoneyTransfer(String fromcountry, String tocountry, double currencyexchangerate, Integer useraccountId,
			Double amount, Double totalamount, String comments, LocalDate date) {
		super();
		this.fromcountry = fromcountry;
		this.tocountry = tocountry;
		this.currencyexchangerate = currencyexchangerate;
		this.useraccountId = useraccountId;
		this.amount = amount;
		this.totalamount = totalamount;
		this.comments = comments;
		this.date = date;
	}
	public String getFromcountry() {
		return fromcountry;
	}
	public void setFromcountry(String fromcountry) {
		this.fromcountry = fromcountry;
	}
	public String getTocountry() {
		return tocountry;
	}
	public void setTocountry(String tocountry) {
		this.tocountry = tocountry;
	}
	public double getCurrencyexchangerate() {
		return currencyexchangerate;
	}
	public void setCurrencyexchangerate(double currencyexchangerate) {
		this.currencyexchangerate = currencyexchangerate;
	}
	public Integer getUseraccountId() {
		return useraccountId;
	}
	public void setUseraccountId(Integer useraccountId) {
		this.useraccountId = useraccountId;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Double getTotalamount() {
		return totalamount;
	}
	public void setTotalamount(Double totalamount) {
		this.totalamount = totalamount;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	public MoneyTransfer get() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
	
		
	
	
	
	
	
	
	





