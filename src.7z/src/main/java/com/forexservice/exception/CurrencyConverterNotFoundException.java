package com.forexservice.exception;

public class CurrencyConverterNotFoundException extends RuntimeException  {

		public CurrencyConverterNotFoundException (String msg) {
			super(msg);

		}
	}






