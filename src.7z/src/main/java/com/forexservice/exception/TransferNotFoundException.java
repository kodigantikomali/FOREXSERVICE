package com.forexservice.exception;

public class TransferNotFoundException extends Exception {

	public TransferNotFoundException(String msg) {
		super(msg);

	}
}



