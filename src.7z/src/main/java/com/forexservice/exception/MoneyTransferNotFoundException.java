package com.forexservice.exception;

public class MoneyTransferNotFoundException extends Exception {
	
		public MoneyTransferNotFoundException(String msg) {
			super(msg);

		}
	}






